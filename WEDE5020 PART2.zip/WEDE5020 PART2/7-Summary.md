# Pretoria Archdiocese - WEDE5020 POE Part 2
Student: Amazima-Agqibile Tyobeka - st10534868

Changelog - Part 1 Feedback Fixed:
- Fixed nav to be same on all pages
- Added 2 locations in contact.html
- Added volunteer/sponsor in enquiry.html (NPO)
- Created proper folders css/, js/, images/

Part 2 CSS:
- External CSS in css/style.css linked to all 5 pages
- Selectors: element, class, descendant, :hover
- Typographic, decorative, layout styling with flex and grid
- Responsive with % and media queries 768px and 480px
- Tested on Chrome DevTools

Sitemap: index > about > services > enquiry > contact